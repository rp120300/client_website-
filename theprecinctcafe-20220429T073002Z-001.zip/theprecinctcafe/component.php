<?php

//start session
session_start();
$conn = mysqli_connect("localhost","root","","sample");
	
	
	if(isset($_POST['add']))
	{
		if(isset($_SESSION["shopping-cart"]))
		{
			$item_array_id = array_column($_SESSION["shopping-cart"],"id");
			if(!in_array($_GET["id"],$item_array_id))
			{
				$count = count($_SESSION["shopping-cart"]);
				$item_array = array(
				'id'           =>    $_GET["id"],
				'foodName'     =>    $_POST["hidden_name"],
				'foodPrice'    =>    $_POST["hidden_price"],
				'foodQuantity' =>    $_POST["quantity"]	
				
				);
				$_SESSION["shopping-cart"][$count] = $item_array;
			}
			
		}
		else
		{
			$item_array= array(
			'id'           =>    $_GET["id"], 
			'foodName'     =>    $_POST["hidden_name"],
			'foodPrice'    =>    $_POST["hidden_price"],
			'foodQuantity' =>    $_POST["quantity"]		
			);
			$_SESSION["shopping-cart"][0] = $item_array;
		}
			
	}
?>