<?php/*
											$conn=mysqli_connect("localhost","root","","order_details");	
											$res = mysqli_query($conn,"select * from `cus_detail` order by id");
											
											
											?>
												<a href="vieworders.php?id=<?php echo $row["id"]; ?>">VIEW ORDERS</a>
											<?php
											
											
										*/?>