<?php
			
$con = mysqli_connect("localhost", "root", "", "order_details");	
	
		
// Check connection
if ($con->connect_error) 
{
  die("Connection failed: " . $con->connect_error);
}

$id = $_GET['id'];
mysqli_query($con,"delete from cus_detail where id=$id");

?>
<script type="text/javascript">
	window.location="manage_food.php";
</script>