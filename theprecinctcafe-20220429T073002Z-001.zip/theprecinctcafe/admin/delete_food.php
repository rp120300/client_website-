<?php
			
$con = mysqli_connect("localhost", "root", "", "sample");	
	
		
// Check connection
if ($con->connect_error) 
{
  die("Connection failed: " . $con->connect_error);
}

$id = $_GET['id'];
mysqli_query($con,"delete from image where id=$id");

?>
<script type="text/javascript">
	window.location="update_delete_food.php";
</script>
