<?php
/*
if(isset($_POST['update_btn']))
{
	$id = $_POST['id'];
	$foodName = $_POST["foodName"];
	$foodPrice = $_POST["foodPrice"];
	$imagename = $_FILES["uploadfile"]["name"];
	
	$food_query = "SELECT * from `image` WHERE id='$id' ";
	$food_query_run = mysqli_query($conn,$food_query);
	
	foreach()
	{
	
	}		
	$query1 = "UPDATE `image` SET foodName='$_POST[foodName]',foodPrice='$_POST[foodPrice]' WHERE id='$_POST[id]' ";
	$query_run = mysqli_query($conn,$query1);
	
	if($query_run )
	{
		echo'<script type="text/javascript"> alert("Data Updated") </script>';
	}
	else 
	{
		echo'<script type="text/javascript"> alert("Data not Updated") </script>';
	}
	
}
*/
?>

<?php
	$conn = mysqli_connect("localhost", "root", "", "sample");

	if(isset($_POST['update_btn']))
	{
		$edit_id = $_POST['edit_id'];
		$foodName = $_POST['foodName'];
		$foodPrice = $_POST['foodPrice'];
		$edit_id = $_POST['edit_id'];
		$uploadfile = $_FILES["foodimage"]['name'];
		
		$query = "UPDATE `image` SET foodName='$foodName', foodPrice='$foodPrice',imagename='$uploadfile'";
		
		$query_run = mysqli_query($conn,$query);
		
		if($query_run)
		{
			move_uploaded_file($_FILES["foodimage"]["tmp_name"],"../assets/img/special-menu/".$_FILES["foodimage"]["name"]));
			$_SESSION['success']="Food Successfully Added";
			header('location:update_delete_food.php');
		}
		else
		{
			$_SESSION['status'] = "Food not updated";
			header('location:update_food.php');
		
		}
	}

?>