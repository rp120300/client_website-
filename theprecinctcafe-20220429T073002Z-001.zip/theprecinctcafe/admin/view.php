<?php

session_start();
if(!isset($_SESSION['username'])){

	header('location:adminlogon.php');

}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>Admin Page</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
	<link rel="stylesheet" type="text/css" href="manage_food.css">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
    
</head>
<body> 


	<!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="navbar-brand">
                        <a class="title logo" href="dashboard.php">Admin Panel</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="dashboard.php">Home</a></li>
                            <li><a href="../adminview_mainpage.php">Main Site</a></li>
							<div class="dropdown">
								<button class="dropbtn">MENU</button>
								<div class="dropdown-content">
									<a href="update_delete_food.php">Delete/Update Food</a>
									<a href="add_food.php">Add food</a>
									<a href="manage_food.php">View orders</a>
									<a href="contact.php">Customer inqueries</a>
								</div>
							</div>
							<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
							</div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->
	<section class="container content-section block-area wow fadeInUp">
	<br>
	<br>
	
		<div class="section-title wow fadeInUp">
		<br>
                <h1 class="title"> <font face="Copperplate Gothic Light" size="10px">View Orders</font></h1>
                <span class="border"></span>
         </div>
		
		<table class="table_food">
			<tr>
				<th>Order ID</th>
				<th>Product Name</th>
				<th>Product Price</th>
				<th>Product Quantity</th>
				<th>Product Total </th>
				<th>Payment</th>
				<th></th>
			</tr>
			
		<?php
		$conn=mysqli_connect("localhost","root","","order_details");
		$id=$_GET["id"];
		$res = mysqli_query($conn,"select * from `order_detail` where cust_id=$id");
		
		while($row=mysqli_fetch_array($res))
		{
		?>
			<tr>
			
				<td><?php echo $row["order_id"]; ?></td>
				<td><?php echo $row["productname"]; ?></td>
				<td><?php echo $row["product_price"];?></td>
				<td><?php echo $row["productquantity"];?></td>
				<td><?php echo $row["ordertotal"];?></td>
				<td colspan=3 width="100px" align="center">
				<?php
					if($row["product_price"]*$row["productquantity"]==$row["ordertotal"])
					{
						?> <h3>Paid</h3> <?php
					}
					else
					{
						?> <h3>Pending</h3> <?php
					}
				?>
				</td>
				
			<tr>
		<?php
		}
		
		?>
			
			
		</table>
		
	</section>
	
	
	
		
	<br>
	<br>
	<br>
	<br>
	
	
	    <!-- Footer start -->
    <footer class="site-footer">
        
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end --> 
</body>
</html>