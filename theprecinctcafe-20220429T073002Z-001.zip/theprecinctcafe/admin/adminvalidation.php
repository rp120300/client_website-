<?php

session_start();
header ('location:adminlogon.php');


$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'adminlogon');

$email = $_POST['user'];
$pass = $_POST['password'];

$s = " select * from admindetails where email = '$email' && password = '$pass'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if($num == 1){
	$_SESSION['username'] = $email;
	echo'<script type="text/javascript"> alert("Hello!!, you have successfully logged in! ") </script>';
	header('location:dashboard.php');
}else{
	echo'<script type="text/javascript"> alert("Invalid Credentials Entered ") </script>';
	header('location:adminlogon.php');
}

?>




