<?php

session_start();
if(!isset($_SESSION['username'])){

	header('location:adminlogon.php');

}

?>


<?php
error_reporting(0);
?>
<?php
/*
  $msg = "";
 
  // If upload button is clicked ...
  if (isset($_POST['upload'])) 
 {
 
	$foodName = $_POST["foodName"];
	$foodPrice = $_POST["foodPrice"];
	
    $imagename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];   
        $folder = "../assets/img/special-menu/".$filename;
         
    $db = mysqli_connect("localhost", "root", "123456", "sample");
 
        // Get all the submitted data from the form
        $sql = "INSERT INTO image (foodName,foodPrice,imagename) VALUES ('$foodName','$foodPrice','$imagename')";
 
        // Execute query
        mysqli_query($db, $sql);
		
         
        // Now let's move the uploaded image into the folder: image
        
		
		if(!$sql)
		{
			echo mysqli_error();
		}	
		elseif(move_uploaded_file($tempname, $folder))  
		{
            $msg = "Image uploaded successfully";
        }
		else
		{
            $msg = "Failed to upload image";
		}
  }
  $result = mysqli_query($db, "SELECT * FROM image");
*/
?>

<?php
	$conn = mysqli_connect("localhost", "root", "", "sample");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>Admin Page</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="update_food.css">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
    
</head>
<body> 


	<!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="navbar-brand">
                        <a class="title logo" href="dashboard.php">Admin Panel</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="dashboard.php">Home</a></li>
                            <li><a href="../adminview_mainpage.php">Main Site</a></li>
							<div class="dropdown">
								<button class="dropbtn">MENU</button>
								<div class="dropdown-content">
									<a href="update_delete_food.php">Delete/Update Food</a>
									<a href="add_food.php">Add food</a>
									<a href="manage_food.php">View orders</a>
									<a href="contact.php">Customer inquiries</a>
								</div>
							</div>
							
							<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
							</div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->
	
	<section class="container content-section block-area gray wow fadeInUp">
	<br>
	
	
	
	
	
	
	
		<h1 class="title"><font face="Copperplate Gothic Light" size="7px">Update the Price </font></h1>
		
		
			<?php
		
			if(isset($_POST['edit_date']))
			{
				$id = $_POST['edit_id'];
				
				$query = "SELECT * FROM image WHERE id='$id'";
				
				$query_run=mysqli_query($conn,$query);
				
				
				foreach($query_run as $row)
				{
?>
		
	


		<form action="" method="POST"  enctype="multipart/form-data>
		
		
		
			<input type="hidden" name="edit_id" value="<?php echo $row['id']?>">
			<table class="table_food">
				<tr>
					<td>Name </td>    
						<td><?php echo $row['foodName']; ?></td>
				</tr>
				
				<tr>
					<td> Current Image</td>
					<td>
						<?php echo'<img src="../assets/img/special-menu/'.$row['imagename'].'" width="100px;" height="100px;">'?>
					</td>
				</tr>
				
				
				<tr>
					<td>Price</td>
					<td>
						<input type="text" name="foodPrice" value="<?php echo $row['foodPrice']?>">
					</td>
				</tr>
	
				<tr>
				
					<td>
						<input type="hidden" name="id" value="<?php echo $id;?>">
						<input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
						
						<div class="col-md-12 col-sm-12 text-right">
							<a href="update_delete_food.php" type="submit" class="btn btn-danger">Cancel</a>
							<input type="submit" name="update_btn" class="btn-secondary ">
						</div>
					</td>
				</tr>
			
			
			</table>
		</form>
		
		

<?php
					
				}

			}
		
		?>
		
		
		
	</section>
	
	
	
		
	<br>
	<br>
	<br>
	<br>
	
	    <!-- Footer start -->
    <footer class="site-footer">
        
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end --> 
</body>
</html>


<?php

if(isset($_POST['update_btn']))
{
	$edit_id = $_POST['edit_id'];
	
	$foodPrice = $_POST["foodPrice"];

	$query1 = "UPDATE `image` SET foodPrice='$_POST[foodPrice]' WHERE id='$_POST[id]' ";
	$query_run = mysqli_query($conn,$query1);
	
	if($query_run)
	{
		move_uploaded_file($tempname, $folder);
		echo'<script type="text/javascript"> alert("Data Updated") </script>';
	}
	else 
	{
		echo'<script type="text/javascript"> alert("Data not Updated") </script>';
	}
	
}

?>


