<?php

session_start();
if(!isset($_SESSION['username'])){

	header('location:adminlogon.php');

}

?>
<?php
error_reporting(0);
?>
<?php
	$msg="";
	
	if(isset($_POST['upload']))
	{
		
		$foodName = $_POST["foodName"];
		$foodPrice = $_POST["foodPrice"];
		$imagename = $_FILES["uploadfile"]["name"];
		$tempname = $_FILES["uploadfile"]["tmp_name"];
			$folder = "../assets/img/special-menu/".$filename;
		
		$db = mysqli_connect("localhost","root","","sample");
		
		$sql = "INSERT INTO `image` (foodName,foodPrice,imagename) VALUES ('$foodName','$foodPrice','$imagename')";
		
		mysqli_query($db,$sql);
		
		if(move_uploaded_file($tempname,$folder))
		{
			echo'<script type="text/javascript"> alert("Failed to add ") </script>';
		}
		else
		{
			echo'<script type="text/javascript"> alert(" Food added to the menu successfully") </script>';
		}
	}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>Admin Page</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="addfood.css">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
    
</head>
<body> 


	<!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="navbar-brand">
                        <a class="title logo" href="dashboard.php">Admin Panel</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="dashboard.php">Home</a></li>
                            <li><a href="../adminview_mainpage.php">Main Site</a></li>
							<div class="dropdown">
								<button class="dropbtn">MENU</button>
								<div class="dropdown-content">
									<a href="update_delete_food.php">Delete/Update Food</a>
									<a href="add_food.php">Add food</a>
									<a href="manage_food.php">View orders</a>
									<a href="contact.php">Customer inquiries</a>
								</div>
							</div>
							<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
							</div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->
	
	
	<div class="block-area">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
				<br>
				<br>
				<br>
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"> <font face="Copperplate Gothic Light" size="10px">Add Food</font></h1>
                        <span class="border"></span>
                    </div>
                </div>
            </div>
			
			<div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="contact-form wow fadeInLeft">
					
					
                        <form action="add_food.php" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <input type="text" placeholder="Title of food" name="foodName" style="border:1.5px solid black">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <input type="number" step=".01" placeholder="Price" name="foodPrice" style="border:1.5px solid black">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <input type="file" placeholder="Choose an Image" name="uploadfile" value="" style="border:1.5px solid black">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-sm-12 text-center">
                                    <input class="btn-submit" type="submit" name="upload" value="Add">
                                </div>
                            </div>
                        </form>
						
                    </div>
                </div>
            </div>
			
		</div>
	</div>
	
	
	    <!-- Footer start -->
    <footer class="site-footer">
        
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end --> 
</body>
</html>


