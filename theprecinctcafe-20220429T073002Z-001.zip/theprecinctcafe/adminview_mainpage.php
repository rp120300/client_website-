<?php
$con = mysqli_connect("localhost", "root", "");

session_start();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>The Precinct Café</title>
    
	
	<!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
    <link href="assets/css/home.css" rel="stylesheet">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
	
	

    <!-- jQuery -->
    <script src="assets/js/jquery-1.11.3.min.js"></script>

    <!-- jQuery UI -->
    <script src="assets/js/jquery-ui-1.12.1.min.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
    
</head>
<body>    
    
    <!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand">
                        <a class="title logo" href="home.php">The Precinct Café</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li class="active"><a href="home.php">Home</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="#gallery">Gallery</a></li>
                            <li><a href="#location">Location</a></li>
                            <li><a href="#contact">Contact</a></li>
							<li><a href="menu.php">Menu</a></li>
							<li class="cart"><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">
							<?php 
								
								if(isset($_SESSION['shopping-cart']))
								{
									$count = count($_SESSION['shopping-cart']);
									echo "$count";
								}
								else
								{
									echo "0";
								}
			
								
							?>
							
							
							</span></a></li>
							
						

							<?php


							if(isset($_SESSION['username']))
							{
							
								?>
									<div class="dropdown">
									<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
									<div class="dropdown-content">
									
										<a href="admin/dashboard.php">ADMIN PANEL</a>
										<a href="logout.php">LOGOUT</a>
										
									</div>
									</div>
								<?php

							}
							else
							{

								?>
								<li><a href="login.php">Login</a></li>
								<li><a href="registration.php">Register</a></li>
								<?php
							}
							
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->
    
    <!-- Slider start -->
    <div id="home" class="slider-area">

        <div class="single-slider" style="background-image: url('assets/img/slider/slider-1.jpg');">
            <div class="slider-table">
                <div class="slider-cell">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-uppercase">
                                <div class="slider-text">
                                    <h1><font face="Copperplate Gothic Light" size="50px">M&nbsp;a&nbsp;k&nbsp;e&nbsp;&nbsp; E&nbsp;v&nbsp;e&nbsp;r&nbsp;y&nbsp;&nbsp; D&nbsp;a&nbsp;y&nbsp;&nbsp; M&nbsp;e&nbsp;m&nbsp;o&nbsp;r&nbsp;a&nbsp;b&nbsp;l&nbsp;e</font></h1>
									<br>
								
									<h2><font face="Maiandra GD" size="4px"><b>A&nbsp;&nbsp;&nbsp; C&nbsp;u&nbsp;p&nbsp;&nbsp;&nbsp; O&nbsp;f&nbsp;&nbsp; &nbsp;C&nbsp;o&nbsp;f&nbsp;f&nbsp;e&nbsp;e&nbsp;&nbsp; &nbsp;I&nbsp;s&nbsp;&nbsp;&nbsp; A&nbsp;l&nbsp;w&nbsp;a&nbsp;y&nbsp;s&nbsp;&nbsp;&nbsp; A&nbsp;&nbsp;&nbsp; G&nbsp;o&nbsp;o&nbsp;d&nbsp;&nbsp;&nbsp; I&nbsp;d&nbsp;e&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;🙂</b></font>    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
        <div class="single-slider" style="background-image: url('assets/img/slider/slider-3.jpg');">
            <div class="slider-table">
                <div class="slider-cell">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-uppercase">
                                <div class="slider-text">
									<h1><font face="Copperplate Gothic Light" size="50px">W&nbsp;e&nbsp;l&nbsp;c&nbsp;o&nbsp;m&nbsp;e&nbsp;&nbsp; t&nbsp;o&nbsp;&nbsp;<br><br> T&nbsp;h&nbsp;e&nbsp;&nbsp; P&nbsp;r&nbsp;e&nbsp;c&nbsp;i&nbsp;n&nbsp;c&nbsp;t &nbsp;&nbsp;C&nbsp;a&nbsp;f&nbsp;e</font></h1>
                                          
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Slider end -->
	

    <!-- About start -->
    <div id="about" class="block-area">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"><font face="Copperplate Gothic Light" size="10px">About Us</font></h1>
                        What a treat it is to be able to sit and have coffee alone! There is no other feeling that compares to this one. 
						Sometimes all we need is nice food and a decent atmosphere, and you are all pumped up!<br><br>

						Does that seem appealing enough? Come see us at The Precinct Café .<br><br>
						The atmosphere sets the tone, and the cuisine is the icing on the cake.   <br>You are welcome to stay as long as you like and simply savor our cuisine. Our team will make you feel at ease. 
						We make certain that the freshest ingredients are used in all of our preparations because customer happiness is our top priority. 
						Our food is always created from scratch and with the highest care.
						
                        <span class="border"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About end -->

    
    <!-- Opening Hour start -->
    <div class="block-area gray">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"> <font face="Copperplate Gothic Light" size="10px">Opening Hours</font></h1>
                        <span class="border"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="opening-box">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12">
                        <div class="opening-box-text wow fadeInUp">
                            <p><font face="Maiandra GD" size="6" > We are open from Monday onwards until Friday</font></p>
                            <h3><font face="Maiandra GD" size="6">7:00AM - 2:00PM</font></h3>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Opening Hour end -->
    

    
    <!-- Gallery start -->
    <div id="gallery" class="block-area gray">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"><font face="Copperplate Gothic Light" size="10px">Gallery</font></h1>
                        <font face="Maiandra GD">You Wouldn't Want To Miss Our Gallery</font>
                        <span class="border"></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-1.jpg" width="250" height="250" >
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp ">  
						<img src="assets/img/gallery/gallery-2.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-3.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-4.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-5.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-6.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-7.jpg" width="250" height="250" >
                    </div>
                </div>
				<div class="col-md-3 col-sm-4">
                    <div class="single-gallery wow fadeInUp">  
						<img src="assets/img/gallery/gallery-8.jpg" width="250" height="250">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Gallery end -->


    
    <!-- Location start  -->
    <div id="location" class="block-area padding-bottom-zero">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"><font face="Copperplate Gothic Light" size="10px">Location</font></h1>
                        <span class="border"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
				<div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                            <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3238.954847108672!2d174.3204336155779!3d-35.72732898018361!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0b7ef000720199%3A0x57fbb03e7854a78f!2sThe%20Precinct%20Cafe!5e0!3m2!1sen!2snz!4v1620780276373!5m2!1sen!2snz" width="1230" height="400" style="border:3px solid black;" allowfullscreen="" loading="lazy"></iframe></p>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Location end -->
    
   <!-- Storing information filled by the users in the contact form into the database -->


<?php
$msg="";
if(isset($_POST['contact_button']))
{
	mysqli_select_db($con,'contactus');

	$name = $_POST['name'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];

	$reg="insert into queries(name,email,subject,message) values ('$name' , '$email' , '$subject' , '$message')";
	mysqli_query($con, $reg);

	if(!$reg)
	{
		echo mysqli_error();
	}
	else
	{
		echo'<script type="text/javascript"> alert(" Message Send Successfull, we will be in touch with you very soon!") </script>';
	}
}


?>

    
    <!-- Contact start -->
    <div id="contact" class="block-area gray">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"><font face="Copperplate Gothic Light" size="10px">Contact Us</font></h1>
                        <font face="Maiandra GD">Do you have any questions about the café? Please complete the quick form and we will be in touch with you.<br> It's that easy!</font>
                        <span class="border"></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 col-md-push-9 col-sm-push-9">
					<br>
					<br>
					<br>
					<div class="single-address wow fadeInRight">
                        <h1>Address</h1>
                        <font face="Maiandra GD">99 Cameron Street, <br>Whangārei 0110, New Zealand.</font>
                    </div>
                    <div class="single-address wow fadeInRight">
                        <h1>Phone</h1>
                        <font face="Maiandra GD">+64 09-988 9959</font>
                    </div>
                </div>
                <div class="col-md-8 col-sm-8 col-md-pull-4 col-sm-pull-4">
                    <div class="contact-form wow fadeInLeft">
                        <form action="" method="POST">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
									
									<input type="text" placeholder="Name" name="name" class="row" style="border:1.5px solid black" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <input type="email" placeholder="Email" name="email" class="row" style="border:1.5px solid black">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <input type="text" placeholder="Subject" name="subject" class="row" style="border:1.5px solid black">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <textarea cols="30" rows="5" placeholder="Message" name="message" class="row" style="border:1.5px solid black"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 text-right">
                                    <button class="btn-submit" type="submit" name="contact_button" >Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact end -->
    
       <!-- Footer start -->
    <footer class="site-footer">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h1 class="title logo">The Precinct café</h1>
                            <div class="bookmarks">
                                <ul>
                                    <li><a href="https://www.facebook.com/theprecinctcafe"><i class="fa fa-facebook"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
					<div class="col-md-3 col-sm-6">
					</div>
					<div class="col-md-3 col-sm-6">
					</div>
					
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h3>Useful information </h3>
                            <ul class="address">
                                <li><i class="fa fa-map-marker"></i>&nbsp;99 Cameron Street, Whangārei 0110, New Zealand.</li>
                                <li><i class="fa fa-phone"></i>+64 09-988 9959 </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end -->   

   <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>    

    <!-- Boostrap Datepicker JS -->
    <script src="assets/js/bootstrap-datepicker.js"></script>

    <!-- Magnific Popup JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    
    <!-- jQuery Easing JS -->
    <script src="assets/js/jquery.easing.min.js"></script>

    <!-- OwlCarousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    
    <!-- WOW JS -->
    <script src="assets/js/wow-1.3.0.min.js"></script>

    
    <!-- Active JS -->
    <script src="assets/js/active.js"></script>

</body>
</html>