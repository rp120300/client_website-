<?php 

session_start();
$conn = mysqli_connect("localhost","root","","order_details");
$res = mysqli_query($conn,"select id from `cus_detail` order by id desc limit 1");

while($row=mysqli_fetch_array($res))
{
	$cust_id=$row['id'];
}

	if(!empty($_SESSION["shopping-cart"]))
	{
		$total=0;
		foreach($_SESSION["shopping-cart"] as $keys => $values)
		{

			echo '<br/><br/><br/><br/><br/>';
			$sql="INSERT INTO `order_detail` (`order_id`, `cust_id`, `productname`, `product_price`, `productquantity`, `ordertotal`) VALUES (null,'".$cust_id."','".$values['foodName']."','".$values['foodPrice']."','".$values['foodQuantity']."','".($values['foodPrice']*$values['foodQuantity'])."')";
			mysqli_query($conn,$sql);
			?>
			<script type="text/javascript">
				alert("Your order is successfully paced!");
				setTimeout(function(){
				window.location='cart.php';},1000);
			</script>
			<?php	
		}
	}
echo'<script type="text/javascript"> alert("Your order is placed successfully!") </script>';
?>


