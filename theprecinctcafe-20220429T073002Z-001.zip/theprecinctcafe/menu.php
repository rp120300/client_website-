<?php
$con = mysqli_connect("localhost", "root", "", "sample");
?>

<?php


require('component.php');

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>The Precinct Café</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
	<link href="menu.css" rel="stylesheet">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
	
	

    <!-- jQuery -->
    <script src="assets/js/jquery-1.11.3.min.js"></script>

    <!-- jQuery UI -->
    <script src="assets/js/jquery-ui-1.12.1.min.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>    
    
    <!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand">
                        <a class="title logo" href="home.php">The Precinct Café</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="home.php">Home</a></li>
                            <li><a href="home.php">About</a></li>
                            <li><a href="home.php">Gallery</a></li>
                            <li><a href="home.php">Location</a></li>
                            <li><a href="home.php">Contact</a></li>
							<li class="active"><a href="menu.php">Menu</a></li>
							<li class="cart"><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">
							<?php 
								
								if(isset($_SESSION['shopping-cart']))
								{
									$count = count($_SESSION['shopping-cart']);
									echo "$count";
								}
								else
								{
									echo "0";
								}
			
								
							?>
							
							
							</span></a></li>
							
						

							<?php


							if(isset($_SESSION['username']))
							{
							
							?>
								<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
								</div>
							<?php

							}
							else
							{

							?>
							<li><a href="login.php">Login</a></li>
							<li><a href="registration.php">Register</a></li>
							<?php
							}
							
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->


		
	<!-- Special start  -->
    <div id="menu" class="block-area gray padding-zero">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-sm-12">
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
                    <div class="section-title wow fadeInUp">
                        <h1 class="title"> <font face="Copperplate Gothic Light" size="10px">Our Menu</font></h1>
                        <font face="Maiandra GD">EAT . DRINK . LOVE </font> 
                        <span class="border"></span>
                    </div>
                </div>
			
			
			<?php
			
				$con = mysqli_connect("localhost", "root", "", "sample");
			
				$sql="SELECT * FROM image ORDER by id ASC";
				
				$res= mysqli_query($con,$sql);
				
				$count = mysqli_num_rows($res);
				
				$sn=1;
				
				if($count>0)
				{
					while($row=mysqli_fetch_assoc($res))
					{
	
						
						?>
                <div class="col-md-4 col-sm-6">
					<form method="POST" action="menu.php?action=add&id=<?php echo $row['id'] ?>">
						<div class="special-menu-box wow fadeInUp"><?php echo'<img src="assets/img/special-menu/'.$row['imagename'].'" width="370px;" height="370px;">'?>
							<div class="special-menu-box-hover text-center">
								<div class="special-box">
									<h1 class="title"><?php echo $row['foodName'];  ?></h1>
									
									<span class="price">$<?php echo $row['foodPrice'];  ?></span>
									<br>
									<input type="text" name="quantity" class="form-control" value="1">
									<br>
									<input type="hidden" name="hidden_name" value="<?php echo $row["foodName"] ?>">
									<input type="hidden" name="hidden_price" value="<?php echo $row["foodPrice"] ?>">
									
									<input type="submit"  class="btn btn-primary add_to_cart" name="add" value="Add to cart">
								</div>
							</div>
						</div>
					</form>
                </div>
                
				<?php
					}
				}
				else
				{
					echo"<tr><td colspan='5' class='error'>Food Not found</td></tr>";
				}
				
			
			?>
				
            </div>
        </div>
    </div>   
    <!-- Special end  -->
	

	
	   <!-- Footer start -->
    <footer class="site-footer">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h1 class="title logo">The Precinct café</h1>
                            <div class="bookmarks">
                                <ul>
                                    <li><a href="https://www.facebook.com/theprecinctcafe"><i class="fa fa-facebook"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
					<div class="col-md-3 col-sm-6">
					</div>
					<div class="col-md-3 col-sm-6">
					</div>
					
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h3>Useful information </h3>
                            <ul class="address">
                                <li><i class="fa fa-map-marker"></i>&nbsp;99  Cameron Street, Whangārei 0110, New Zealand.</li>
                                <li><i class="fa fa-phone"></i>+64 09-988 9959 </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end -->  

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>    

    <!-- Boostrap Datepicker JS -->
    <script src="assets/js/bootstrap-datepicker.js"></script>

    <!-- Magnific Popup JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    
    <!-- jQuery Easing JS -->
    <script src="assets/js/jquery.easing.min.js"></script>

    <!-- OwlCarousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    
    <!-- WOW JS -->
    <script src="assets/js/wow-1.3.0.min.js"></script>

    
    <!-- Active JS -->
    <script src="assets/js/active.js"></script>

</body>
</html>