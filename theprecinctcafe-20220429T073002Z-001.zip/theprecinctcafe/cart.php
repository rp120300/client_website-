<?php 
$con = mysqli_connect("localhost", "root", "", "sample");

require('component.php');

?>



<DOCTYPE html>

<html>
<head>

  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>Cart Page</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
	
	



<style>

/*0. Default CSS*/
@import url('https://fonts.googleapis.com/css?family=Roboto:100,300,400,400i,500,700');
@import url('https://fonts.googleapis.com/css?family=Dancing+Script:700');

body {
    font-family: 'Roboto', sans-serif;
    font-weight: 400;
    color: #2c2626;
    font-size: 15px;
    line-height: 25px;
}

img {
    max-width: 100%;
}

a {
    color: #F39C12;
}

a:hover {
    color: #F39C12;
    text-decoration: underline;
}

.btn-table,
a.btn-table {
    background-color: #F39C12;
    border: 2px solid #fff;
    font-size: 24px;
    color: #fff;
    text-align: center;
    padding: 18px 50px;
    display: inline-block;
    -webkit-transition: 0.2s;
    transition: 0.2s;
    font-weight: 700;
}

.btn-table:hover,
a.btn-table:hover {
    background-color: #000;
    text-decoration: none;
    color: #fff;
}

.btn-table:focus,
a.btn-table:focus {
    outline: 0;
    text-decoration: none;
}


.block-area {
    padding: 75px 0 40px;
}

.padding-zero {
    padding: 0;
}

.padding-top-zero {
    padding-top: 0;
}

.padding-bottom-zero {
    padding-bottom: 0;
}

.padding-right-zero {
    padding-right: 0;
}

.padding-left-zero {
    padding-left: 0;
}

.title {
    font-family: 'Dancing Script', cursive;
    font-weight: 700;
}

.block-area.gray {
    background: #f6f6f6;
}

.section-title {
    font-size: 18px;
    color: #2C2626;
    text-align: center;
    margin-bottom: 100px;
    line-height: 30px;
}

.section-title h1 {
    font-size: 60px;
    margin: 0 0 40px;
}

.section-title h3 {
    line-height: 45px;
    margin: 0;
    font-weight: 300;
}

.border {
    background-color: #2c2626;
    height: 1px;
    width: 170px;
    display: block;
    margin: 30px auto 0;
}

.datepicker {
    margin-top: -24px;
}

.icon-arrow-left {
    background-position: center 3px;
    background-image: url("../img/arrow-left.png");
    background-repeat: no-repeat;
    display: inline-block;
    width: 14px;
    height: 14px;
    line-height: 14px;
    vertical-align: text-top;
}

.icon-arrow-right {
    background-position: center 3px;
    background-image: url("../img/arrow-right.png");
    background-repeat: no-repeat;
    display: inline-block;
    width: 14px;
    height: 14px;
    line-height: 14px;
    vertical-align: text-top;
}



/*3. Header area CSS*/
.logo {
    color: #fff;
    font-size: 37px;
}

.navbar-default .navbar-toggle {
    border-color: #fff;
    margin-right: 0;
}

.navbar-default .navbar-toggle:hover,
.navbar-default .navbar-toggle:focus {
    background-color: transparent;
    border-color: #F39C12;
}

.navbar-default .navbar-toggle .icon-bar {
    background-color: #fff;
}

.navbar-default .navbar-toggle:hover .icon-bar,
.navbar-default .navbar-toggle:focus .icon-bar {
    background-color: #F39C12;
}

.navbar-brand a:hover {
    color: #fff;
    text-decoration: none;
}

.navbar {
    background: #000000;
    padding: 25px 0;
    border: 0;
    border-radius: 0;
    margin: 0;
}

.navbar-default .navbar-nav > li > a {
    color: #fff;
    font-size: 16px;
    font-weight: 700;
    -webkit-transition: 0.2s;
    transition: 0.2s;
}

.navbar-default .navbar-nav > li > a:hover {
    color: #F39C12;
}

.navbar-default .navbar-nav> .active >a,
.navbar-default .navbar-nav > .active > a:hover,
.navbar-default .navbar-nav>.active>a:focus {
    color: #F39C12;
    background-color: transparent;
    outline: 0;
}

.navbar-default .navbar-nav>.active>a:focus,
.navbar-default .navbar-nav> a:focus {
    background-color: transparent;
}

.navbar-default .navbar-nav>li>a:focus {
    color: #fff;
}

.navbar-default .navbar-nav > li:last-child > a {
    padding-right: 0;
}

/*dropdown */
.dropbtn {
  background-color: black;
  padding: 16px;
  font-size: 16px;
  border: none;
  margin-right: 0;
  color: #E59494;
  font-weight: 700;
  -webkit-transition: 0.2s;
  transition: 0.2s;
  margin-top:-4px;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}
/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
/* Links inside the dropdown */
.dropdown-content a {
	font-weight: 700;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {
	background-color: black;
	color:#F39C12;
	border:1px solid white;
}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
	background-color: black;
	color:#F39C12;
}




/*Cart item*/

	
.table_food{

	font-weight: bold;
	font-size:1.5em;
	color: black;
	margin-left:200px;
	width:100%;
	font-family:Maiandra GD;
	display: inline-block;
	position:static;
}


table tr th{

	color:#F39C12;
	text-align: left;
	padding:3%;
	position:static;
}

table tr td{

	padding:3%;
	margin-top:90px;
	text-align:left;
	width:200px;
	
}



.btn-secondary{
	color: #2C2626;
    font-size: 17px;
    font-weight: 700;
    text-transform: uppercase;
    background: #C3DEFC;
    border: 2px solid #2C2626;
    display: inline-block;
    width: auto;
    padding: 10px 15px;
    -webkit-transition: 0.3s;
    transition: 0.3s;
	
}

.btn-secondary:hover{
    background: #2C2626;
    text-decoration: none;
    color: #fff;
}





/*16. Footer area CSS*/
.footer-area {
    background: #000000;
    padding: 40px;
    color: #fff;
}

</style>
	
</head>


<body>



 <!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand">
                        <a class="title logo" href="home.php">The Precinct Café</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="home.php">Home</a></li>
                            <li><a href="home.php">About</a></li>
                            <li><a href="home.php">Gallery</a></li>
                            <li><a href="home.php">Location</a></li>
                            <li><a href="home.php">Contact</a></li>
							<li><a href="menu.php">Menu</a></li>
							<li class="cart active"><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">
							<?php 
								
								if(isset($_SESSION['shopping-cart']))
								{
									$count = count($_SESSION['shopping-cart']);
									echo "$count";
								}
								else
								{
									echo "0";
								}
			
								
							?>
							
							
							</span></a></li>
							
						

							<?php


							if(isset($_SESSION['username']))
							{
							
							?>
								<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
								</div>
							<?php

							}
							else
							{

							?>
							<li><a href="login.php">Login</a></li>
							<li><a href="registration.php">Register</a></li>
							<?php
							}
							
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

<!-- Navigation end -->


	<section class="container content-section block-area gray wow fadeInUp">
	<br>
	<br>
	
		<div class="section-title wow fadeInUp">
		<br>
                <h1 class="title"> <font face="Copperplate Gothic Light" size="10px">Cart</font></h1>
                <span class="border"></span>
         </div>
			<form="cart.php" method="get" class="table_food">
		
				<table>
					<tr>
						<th colspan="2">Name</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Total</th>
						<th></th>
					</tr>
					<?php 
					
					$sql="SELECT * FROM image ";
					$res= mysqli_query($con,$sql);
						
					if(!empty($_SESSION["shopping-cart"]))
					{
						$total =0;
						foreach($_SESSION["shopping-cart"] as $keys => $values)
						{
					?>
					<tr>
							
						<td colspan="2"><?php echo $values['foodName'];?></td>
						<td><?php echo $values['foodQuantity'];?></td>
						<td>$<?php echo $values['foodPrice'];?></td>
						<td><?php echo number_format($values['foodQuantity'] * $values['foodPrice'],2); ?></td>
						<td>
							<a href="cart.php?action=delete&id=<?php echo $values["id"]; ?>"> 
							<button class='btn btn-danger '>Delete</button>
							</a>
						</td>
					</tr>
					
					<?php 
						$total = $total + ($values['foodQuantity'] * $values['foodPrice']);
						
						 
						}	
						
					?>
					<tr>
						<th colspan="4" rowspan="2">
							<td width="300px"><font size="5">
								<div class="row">
									<div class="col-md-12 col-sm-12 text-center">
										Total: $<?php echo number_format($total,2);
										$_SESSION["pay"] = $total;
										
										?>
									</div>
								</div>
							</font></td>
						</th>
					</tr>
	
					<?php
					
	
					
					} 
					else
					{
					echo"<tr><td colspan='2'>Food Not found</td><td></td><td></td></tr>";
					}
					
						
					?>
					<tr></tr>
					<tr></tr>
					<tr>
						<th colspan="3">
							<td width="300px">
								<div class="row">
									<div class="col-md-12 col-sm-12 text-left">
										<a href="checkout.php" class="btn-secondary" type="submit">Checkout</a>
									</div>
								</div>
							</td>
						</th>
					</tr>
				
							
	<?php
	
		if(isset($_GET['action']))
		{
			if($_GET['action']=="delete")
			{
				foreach($_SESSION['shopping-cart'] as $keys => $values)
				{
					if($values['id']==$_GET['id'])
					{
						unset($_SESSION['shopping-cart'][$keys]);
					}
				}
				
			}
		}
		
	
	?>
			
					
					
				</table>
			</form>

		
	</section>
	
	
	<br>
	<br>
	<br>
	<br>
	
	
	    <!-- Footer start -->
    <footer class="site-footer">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h1 class="title logo">The Precinct café</h1>
                            <div class="bookmarks">
                                <ul>
                                    <li><a href="https://www.facebook.com/theprecinctcafe"><i class="fa fa-facebook"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
					<div class="col-md-3 col-sm-6">
					</div>
					<div class="col-md-3 col-sm-6">
					</div>
					
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h3>Useful information </h3>
                            <ul class="address">
                                <li><i class="fa fa-map-marker"></i>&nbsp;99  Cameron Street, Whangārei 0110, New Zealand.</li>
                                <li><i class="fa fa-phone"></i>+64 09-988 9959 </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end -->  

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>    

    <!-- Boostrap Datepicker JS -->
    <script src="assets/js/bootstrap-datepicker.js"></script>

    <!-- Magnific Popup JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    
    <!-- jQuery Easing JS -->
    <script src="assets/js/jquery.easing.min.js"></script>

    <!-- OwlCarousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    
    <!-- WOW JS -->
    <script src="assets/js/wow-1.3.0.min.js"></script>

    
    <!-- Active JS -->
    <script src="assets/js/active.js"></script>
	
</body>
</html>