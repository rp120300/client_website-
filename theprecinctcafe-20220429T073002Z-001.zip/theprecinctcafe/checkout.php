<?php

$conn = mysqli_connect("localhost","root","","order_details");
session_start();
if(!isset($_SESSION['username']))
{
	header('location:login.php');
}
else
{
	
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>The Precinct Café</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
	 <link href="checkout.css" rel="stylesheet">
	

    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">


    <!-- jQuery -->
    <script src="assets/js/jquery-1.11.3.min.js"></script>

    <!-- jQuery UI -->
    <script src="assets/js/jquery-ui-1.12.1.min.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>    
    
    <!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand">
                        <a class="title logo" href="home.php">The Precinct Café</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li class="active"><a href="home.php">Home</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="#gallery">Gallery</a></li>
                            <li><a href="#location">Location</a></li>
                            <li><a href="#contact">Contact</a></li>
							<li><a href="menu.php">Menu</a></li>
							<li><a href="cart.html"><span class="glyphicon glyphicon-shopping-cart"></span></a></li>
							<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
							</div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->
	
	<div id="checkout" class="block-area gray">
		<div class="container">
			<div class="checkout-box">
			<div class="row">
			<div class="col-md-8 col-md-push-5 checkout">
				<h1 class="title"><font face="Copperplate Gothic Light" size="7px" style="margin-left:60px">Checkout</font></h1>
				<br>
				<br>
				
				<h1 class="title"><font face="Copperplate Gothic Light" size="5px" style="margin-left:60px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Personal Details</font></h1>
				<br>
				<br>
				<form action="" name="form1" method="post">
					<div class="form-group">
						<label><font face="Maiandra GD" size="4px">Full Name</font></label>
						<input type="text" name="custname" class="form-control" required>
					</div>
					<div class="form-group">
						<label><font face="Maiandra GD" size="4px">Email</font></label>
						<input type="email" name="custemail" class="form-control" required>
					</div>
					<div class="form-group">
						<label><font face="Maiandra GD" size="4px">Phone Number</font></label>
						<input type="tel" name="custphone" class="form-control" placeholder="(022)-1111111" required>
					</div>
					<div class="form-group">
						<label><font face="Maiandra GD" size="4px">Address</font></label>
						<textarea rows="4" cols="55" name="custaddress"></textarea>
					</div>
					<br>
					<br>
				
				<br>
				<br>				
				<h1 class="title"><font face="Copperplate Gothic Light" size="5px" style="margin-left:60px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Payment Method</font></h1>
				<br>
				<br>
				<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=27XYLLRVFR226" type="submit" class="btn btn-primary"> Pay by Paypall</a>
				<br>
				<br>
				<h1><font face="Maiandra GD" size="4px" align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********OR********</font></h1>
				<br>
				<br>
				
			
	
					<button name="submit1" type="submit" class="btn btn-primary"> Pay by Card</button>
					
					<br>
					<br>
					<label><font face="Maiandra GD" size="4px">Accepted Cards</font></label>
					<div class="icon-container">
						 <i class="fa fa-cc-visa" style="color:navy;"></i>
						 <i class="fa fa-cc-amex" style="color:blue;"></i>
				   	     <i class="fa fa-cc-mastercard" style="color:red;"></i>
					     <i class="fa fa-cc-discover" style="color:orange;"></i>
					</div>
				<?php
			
				if(isset($_POST["submit1"]))
				{
							
					mysqli_query($conn,"insert into `cus_detail` values('','$_POST[custname]','$_POST[custemail]','$_POST[custphone]','$_POST[custaddress]') ");
					
					
					
					$res = mysqli_query($conn,"select id from `cus_detail` order by id desc limit 1");
					while($row = mysqli_fetch_array($res))
					{
						$_SESSION["cust_id"] = $row["id"];
					}
					
					
					?>
						<script type="text/javascript">
						alert("Transferring you to the payment page");
						setTimeout(function(){
						window.location='purchase_method.php';},1000);
						</script>
					<?php
					
				}
				
				
				
			
				?>
					
					
				</font></form>
			
			
			
			</div>
			</div>
			</div>
		</div>
	</div>
	
	
	<!-- Footer start -->
    <footer class="site-footer">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h1 class="title logo">The Precinct café</h1>
                            <div class="bookmarks">
                                <ul>
                                    <li><a href="https://www.facebook.com/theprecinctcafe"><i class="fa fa-facebook"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
					<div class="col-md-3 col-sm-6">
					</div>
					<div class="col-md-3 col-sm-6">
					</div>
					
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h3>Useful information </h3>
                            <ul class="address">
                                <li><i class="fa fa-map-marker"></i>&nbsp;99 Cameron Street, Whangārei 0110, New Zealand.</li>
                                <li><i class="fa fa-phone"></i>+64 09-988 9959 </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end -->   

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>    

    <!-- Boostrap Datepicker JS -->
    <script src="assets/js/bootstrap-datepicker.js"></script>

    <!-- Magnific Popup JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    
    <!-- jQuery Easing JS -->
    <script src="assets/js/jquery.easing.min.js"></script>

    <!-- OwlCarousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    
    <!-- WOW JS -->
    <script src="assets/js/wow-1.3.0.min.js"></script>

	<!-- Cart Javascript -->
	<script src="store.js"></script>
    
    <!-- Active JS -->
    <script src="assets/js/active.js"></script>

</body>
</html>