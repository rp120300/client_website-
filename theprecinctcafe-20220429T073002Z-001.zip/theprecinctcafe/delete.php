
<?php

session_start();

if(isset($GET["action"]))
{
	if($_GET["action"]=="delete")
	{
		foreach($_SESSION["shopping-cart"] as $keys => $values)
		{
			if($values["id"]==$_GET['id'])
			{
				unset($_SESSION["shopping-cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="cart.php"</script>';
			}
		}
	}
}

?>