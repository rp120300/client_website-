(function ($) {
    "use strict";

    $(document).ready(function($){
        $(".navbar-nav a").click(function(event) {
            $(".navbar-collapse").collapse("hide");
        });

        $("body").scrollspy({ 
            target: ".navbar-collapse",
            offset: 95
        }); 

        $(".navbar-nav a,.scroll").bind("click", function(event) {
            var $anchor = $(this);
            var header = $(".navbar-default").outerHeight();
            $("html, body").stop().animate({
                scrollTop : $($anchor.attr("href")).offset().top - header + 15 + "px"
            }, 1200, "easeInOutExpo");
                            
            event.preventDefault();
        });   

        $(".slider-area").owlCarousel({
            items: 1,
            dots: true,
            autoplay: true,
            loop: true,
            mouseDrag: false,
            touchDrag: false
        });

        $(".slider-area").on("translate.owl.carousel", function(){
            $(".slider-text h2, .slider-text h1").removeClass("animated fadeInUp").css("opacity", "0");
            $(".slider-text .btn-table").removeClass("animated fadeInDown").css("opacity", "0");
        });
        
        $(".slider-area").on("translated.owl.carousel", function(){
            $(".slider-text h2, .slider-text h1").addClass("animated fadeInUp").css("opacity", "1");
            $(".slider-text .btn-table").addClass("animated fadeInDown").css("opacity", "1");
        });


        $(".testimonial-list").owlCarousel({
            items: 1,
            dots: true,
            autoplay: true,
            loop: true
        });

        $(".gallery-lightbox").magnificPopup({
            type: 'image',
            gallery: {
                enabled: true
            }
        });

        $("#datepicker").datepicker({
            autoclose: true
        });

        new WOW().init();
    });

    $(window).load(function(){
        $(".foodcafe-preloader").fadeOut(500);
    });

}(jQuery)); 