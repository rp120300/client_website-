<?php
$con = mysqli_connect("localhost", "root", "");
?>

<?php

session_start();

$msg="";

if(isset($_POST['login']))
{
	mysqli_select_db($con,'userregistration');

	$name = $_POST['user'];
	$pass = $_POST['password'];

	$s = " select * from usertable where name = '$name' && password = '$pass'";

	$result = mysqli_query($con, $s);

	$num = mysqli_num_rows($result);

	if($num == 1){
		
		echo'<script type="text/javascript"> alert("Hello!!, you have successfully logged in! ") </script>';
		header('location:home.php');
		$_SESSION['username'] = $name;
		
	}
	else
	{
		echo'<script type="text/javascript"> alert("Please try again, as either the username or password you have entered is invalid.") </script>';
	}
}
 

?>


<DOCTYPE html>
<html>
<head>
	<title>User and Admin Login</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <title>The Precinct Café</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/fevicon/fevicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!-- Font awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    
    <!-- Magnific popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Boostrap Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    
    <!-- Main CSS -->
	<link rel="stylesheet" type="text/css" href="login.css">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="assets/js/jquery-1.11.3.min.js"></script>

    <!-- jQuery UI -->
    <script src="assets/js/jquery-ui-1.12.1.min.js"></script>
</head>

<body>
<!-- Navigation start -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-2">  
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand">
                        <a class="title logo" href="home.php">The Precinct Café</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-10">
                    <div id="navbar-collapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right text-uppercase">
                            <li><a href="home.php" id="home">Home</a></li>
                            <li><a href="home.php" id="about">About</a></li>
                            <li><a href="home.php" id="gallery">Gallery</a></li>
                            <li><a href="home.php" id="location">Location</a></li>
                            <li><a href="home.php" id="contact">Contact</a></li>
							<li><a href="menu.php" id="contact">Menu</a></li>
							<li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">
							
							<?php 
								
								if(isset($_SESSION['shopping-cart']))
								{
									$count = count($_SESSION['shopping-cart']);
									echo "$count";
								}
								else
								{
									echo "0";
								}
			
								
							?>
							
							
							</span></a></li>
							
							
							<?php


							if(isset($_SESSION['username']))
							{
							
							?>
								<div class="dropdown">
								<button class="dropbtn">WELCOME <?php echo $_SESSION['username'];?> :)</button>
								<div class="dropdown-content">
									<a href="logout.php">LOGOUT</a>
								</div>
								</div>
							<?php

							}
							else
							{

							?>
							<li class="active"><a href="login.php">Login</a></li>
							<li><a href="registration.php">Register</a></li>
							<?php
							}
							
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navigation end -->





	<div id="login" class="block-area gray">
		<div class="container">
			<div class="login-box">
			<div class="row">
			<div class="col-md-6 login-left">
				<h1 class="title"><font face="Copperplate Gothic Light" size="6px" style="margin-left:60px">User Login</font></h1>
				<br>
				<br>
				<form action="" method="post">
					<div class="form-group">
						<label>Username</label>
						<input type="text" name="user" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="password" class="form-control" required>
					</div>
					<button type="submit" class="login_button btn btn-primary" name="login"> Login</button>
					
					<h6> Do not have an account ? Please &nbsp; <a href="registration.php" type="submit" class=" register_button btn btn-secondary"> Register</a></h6>
					
				</font></form>
			
			
			</div>
			
			<div class="vl"></div>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			
            <div class="col-md-6 col-md-push-6   login-right">
				<form action="../theprecinctcafe/admin/adminlogon.php">
				
					<button type="submit" class="admin_button btn btn-primary">Click here for Admin Login</button>
				</div>
				
			</div>
			</div>
			</div>
		</div>
	</div>
	<br>
	
	    <!-- Footer start -->
    <footer class="site-footer">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h1 class="title logo">The Precinct café</h1>
                            <div class="bookmarks">
                                <ul>
                                    <li><a href="https://www.facebook.com/theprecinctcafe"><i class="fa fa-facebook"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
					<div class="col-md-3 col-sm-6">
					</div>
					<div class="col-md-3 col-sm-6">
					</div>
					
                    <div class="col-md-3 col-sm-6">
                        <div class="widget">
                            <h3>Useful information </h3>
                            <ul class="address">
                                <li><i class="fa fa-map-marker"></i>99 Cameron Street, Whangārei 0110, New Zealand.</li>
                                <li><i class="fa fa-phone"></i>+64 09-988 9959 </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        &copy; 2021 Copyright ThePrecinctCafé </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer end --> 
</body>
</html>